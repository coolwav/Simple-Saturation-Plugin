# Simple-Saturation-Plugin
This is my first plugin. Published under the GPLv3 open source license. Made with HISE.
I am making my best effort to comply with the GPLV3 open source license and HISE poliicies.
Please email me at contactcoolwav@gmail.com if I am missing anything.
